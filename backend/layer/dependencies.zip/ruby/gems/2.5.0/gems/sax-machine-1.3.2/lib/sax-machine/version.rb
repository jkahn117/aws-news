module SAXMachine
  VERSION = "1.3.2"
end
