#ifndef NOKOGIRI_XML_RELAX_NG
#define NOKOGIRI_XML_RELAX_NG

#include <nokogiri.h>

void init_xml_relax_ng();

extern VALUE cNokogiriXmlRelaxNG;
#endif
