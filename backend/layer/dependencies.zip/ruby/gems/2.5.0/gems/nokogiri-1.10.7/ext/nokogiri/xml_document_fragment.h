#ifndef NOKOGIRI_XML_DOCUMENT_FRAGMENT
#define NOKOGIRI_XML_DOCUMENT_FRAGMENT

#include <nokogiri.h>

void init_xml_document_fragment();

extern VALUE cNokogiriXmlDocumentFragment;
#endif

