#ifndef NOKOGIRI_XML_TEXT
#define NOKOGIRI_XML_TEXT

#include <nokogiri.h>

void init_xml_text();

extern VALUE cNokogiriXmlText ;
#endif
