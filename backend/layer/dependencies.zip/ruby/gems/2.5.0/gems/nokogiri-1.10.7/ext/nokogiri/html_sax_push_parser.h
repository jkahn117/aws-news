#ifndef NOKOGIRI_HTML_SAX_PUSH_PARSER
#define NOKOGIRI_HTML_SAX_PUSH_PARSER

#include <nokogiri.h>

void init_html_sax_push_parser();

extern VALUE cNokogiriHtmlSaxPushParser ;
#endif
