require 'spec_helper'

describe Parslet::Atoms::Infix do

end