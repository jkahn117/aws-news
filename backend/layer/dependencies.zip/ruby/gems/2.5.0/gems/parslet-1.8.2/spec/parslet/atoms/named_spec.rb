require 'spec_helper'

describe Parslet::Atoms::Named do
end