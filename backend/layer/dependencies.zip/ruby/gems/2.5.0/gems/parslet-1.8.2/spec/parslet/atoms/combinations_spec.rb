require 'spec_helper'

describe "Parslet combinations" do
  include Parslet
end